function request(paras)
{
	var url = location.href;
	var paraString = url.substring(url.indexOf("?")+1,url.length).split("&"); 
	var paraObj = {}
	for (i=0; j=paraString[i]; i++){
		paraObj[j.substring(0,j.indexOf("=")).toLowerCase()] = j.substring(j.indexOf("=")+1,j.length);
	}
	var returnValue = paraObj[paras.toLowerCase()];
	if(typeof(returnValue)=="undefined"){
		return "";
	}else{
		return returnValue;
	}
}

function pre_assure_info(){
	/*if($("input[name='name_name']").val() == ""){
		$('#id_msg').html("please enter the name!");
		$("input[name='name_name']").focus;
		return false;
	}*/
	post_assure_info();
}

function post_assure_info(){
	var pjt_id=request("pjt_id");
	var task_id=request("task_id");
	$.post("/autotestPlatform/assureinfo/",{pjt_id:pjt_id,task_id:task_id},
	function(data){
		var update_result=data.update_result;
		
		if(update_result == "1"){
			alert("任务启动成功");
			window.location.href="/autotestPlatform/testrunner/?task_id="+task_id+"&pjt_id="+pjt_id;
		}
		else{
			alert("任务启动失败");
		}
	},
	"json");//这里返回的类型有：json,html,xml,text*/
}

