function request(paras)
{
	var url = location.href;
	var paraString = url.substring(url.indexOf("?")+1,url.length).split("&"); 
	var paraObj = {}
	for (i=0; j=paraString[i]; i++){
		paraObj[j.substring(0,j.indexOf("=")).toLowerCase()] = j.substring(j.indexOf("=")+1,j.length);
	}
	var returnValue = paraObj[paras.toLowerCase()];
	if(typeof(returnValue)=="undefined"){
		return "";
	}else{
		return returnValue;
	}
}

function pre_add_task(){
	if($("input[name='name_name']").val() == ""){
		$('#id_msg').html("please enter the name!");
		$("input[name='name_name']").focus;
		return false;
	}
	post_add_task();
}

function post_add_task(){
	var pjt_id=request("pjt_id");
	$.post("/autotestPlatform/task/",{name_name:$("input[name='name_name']").val(),name_version:$("input[name='name_version']").val(),
	name_info:$("input[name='name_info']").val(),name_testtype:$("input[name='name_testtype']").val(),name_processtype:$("input[name='name_processtype']").val(),
	name_filepath:$("input[name='name_filepath']").val(),pjt_id:pjt_id},
	function(data){
		var add_result=data.add_result;
		var task_id=data.last_id;
		if(add_result == "1"){
			alert("任务创建成功");
			window.location.href="/autotestPlatform/assureinfo/?task_id="+task_id+"&pjt_id="+pjt_id;
		}
		else{
			alert("任务创建失败");
		}
	},
	"json");//这里返回的类型有：json,html,xml,text
}


