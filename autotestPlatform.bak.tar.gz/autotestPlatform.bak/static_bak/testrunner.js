$(document).ready(function(){
	run();
});


//time可以通过用户输入的值来动态改变，当用户完成输入后用过clearInterval(interval)清理 
//之前的调度器，然后再调用run方法，这样修改后的调度器就起作用了。 

var time = 1000;
var interval; //调度器对象。 
function run(){   
interval = setInterval(fun,time); 
}

function fun(){
	//alert(jsonData());
	$.ajax({
		type: "post",//使用post方法访问后台
		dataType: "json",//返回json格式的数据
		url: "/autotestPlatform/testrunner/",//要访问的后台地址
		contentType: "application/json; charset=utf-8",
		cache: false,
		data: jsonData(),//要发送的数据
		//start : function(){},
		//complete :function(){$("#load").hide();},//AJAX请求完成时隐藏loading提示
		success: function(msg){//msg为返回的数据，在这里做数据绑定
			var status = String(msg.status);
			
			if(status == "1" || status == "0" || status == "2"){
				document.getElementById("id_task_status").innerHTML="<img src='/static/l_loading.gif'>";
				document.getElementById("id_status_001").innerHTML="<img src='/static/r_loading.gif'>";
			}
			if(status == "3" || status == "4"){
				document.getElementById("id_task_status").innerHTML="a:"+status;
				document.getElementById("id_status_001").innerHTML="a:"+status;
			}
		}
	});
	//alert("test");
}

$.extend({  
getUrlVars: function(){  
var vars = [], hash;  
var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');  
for(var i = 0; i < hashes.length; i++)  
{  
hash = hashes[i].split('=');  
vars.push(hash[0]);  
vars[hash[0]] = hash[1];  
}  
return vars;  
},  
getUrlVar: function(name){  
return $.getUrlVars()[name];  
}  
}); 

function jsonData(){
var task_id=request("task_id");
var pjt_id=request("pjt_id");

var jsonStr="({"; 
jsonStr+="\"task_id\":";
jsonStr+="\"";
jsonStr+=task_id;
jsonStr+="\""; 
jsonStr+=","; 

jsonStr+="\"pjt_id\":";
jsonStr+="\"";
jsonStr+=pjt_id
jsonStr+="\""; 
jsonStr+="})"; 

//return eval(jsonStr);
return jsonStr;
}

function request(paras)
    { 
        var url = location.href;
        var paraString = url.substring(url.indexOf("?")+1,url.length).split("&"); 
        var paraObj = {} 
        for (i=0; j=paraString[i]; i++){ 
        paraObj[j.substring(0,j.indexOf("=")).toLowerCase()] = j.substring(j.indexOf("=")+1,j.length); 
        } 
        var returnValue = paraObj[paras.toLowerCase()]; 
        if(typeof(returnValue)=="undefined"){ 
        return ""; 
        }else{ 
        return returnValue; 
        } 
    }

