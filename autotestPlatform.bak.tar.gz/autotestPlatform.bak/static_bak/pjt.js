function pre_add_pjt(){
	if($("input[name='pjt_name']").val() == ""){
		$('#id_msg').html("please enter the name!");
		$("input[name='pjt_name']").focus;
		return false;
	}
	
	/*if($("input[name='pjt_info']").val() == ""){
		$('#id_msg').html("please enter the info!");
		$("input[name='pjt_info']").focus;
		return false;
	}*/
	post_add_pjt();
}

function post_add_pjt(){
	$.post("/autotestPlatform/pjt/",{pjt_name:$("input[name='pjt_name']").val(),pjt_info:$("input[name='pjt_info']").val()},
	function(data){
		var add_result=data.add_result;
		var pjt_id=data.last_id;
		if(add_result == "1"){
			alert("项目创建成功");
			window.location.href="/autotestPlatform/task/?pjt_id="+pjt_id;
		}
		else{
			alert("项目创建失败");
		}
	},
	"json");//这里返回的类型有：json,html,xml,text
}
